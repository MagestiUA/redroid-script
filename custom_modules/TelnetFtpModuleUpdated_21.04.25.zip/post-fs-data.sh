/data/adb/modules/TelnetFtpModule/busybox tcpsvd -vE 0.0.0.0 3222 ftpd -w / &
/data/adb/modules/TelnetFtpModule/busybox telnetd -p 2222 -l /system/bin/sh &
/data/adb/modules/TelnetFtpModule/busybox httpd -f -p 4222 -h /data/local/tmp/ &
setprop service.adb.tcp.port 6001
stop adbd
start adbd

mkdir -p $MODDIR/system/bin
cp -f /data/adb/modules/TelnetFtpModule/service.sh $MODDIR/system/bin/service.sh
sh $MODDIR/system/bin/service.sh
